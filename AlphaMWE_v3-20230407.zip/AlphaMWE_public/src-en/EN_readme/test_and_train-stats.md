Language: EN
============

## File: EN/train.cupt
* Sentences: 3471
* Tokens: 53201
* Total VMWEs: 331
  * `IAV`: 16
  * `LVC.cause`: 7
  * `LVC.full`: 78
  * `VID`: 60
  * `VPC.full`: 151
  * `VPC.semi`: 19

Language: EN
============

## File: EN/test.cupt
* Sentences: 3965
* Tokens: 71002
* Total VMWEs: 501
  * `IAV`: 44
  * `LVC.cause`: 36
  * `LVC.full`: 166
  * `MVC`: 4
  * `VID`: 79
  * `VPC.full`: 146
  * `VPC.semi`: 26


The extracted 750 sentences from both training and testing files of EN corpus have a total number of vMWEs 832 (331+501), IAV 60 (16+44), LVC.cause 43 (7+36), LVC.full 244 (78+166), MVC 4 (0+4), VID 139 (60+79), VPC.full 297 (151+146), VPC.semi 45 (19+26) \footnote{This indicated that the training file size is smaller than the testing file size, also the training file has fewer number of annotations of PARSEME EN v1.1. }. 
